"use strict";



const MONEY = 9999999999;
const POP = 6767676; 
const POP_PIN_KEY = "kaizen.pop";

const MIRROR_KEY = "kaizen.state";


const LANDMARKS = [
  { id: "helang", name: "Dataran Lang 4×4", w: 4, h: 4 },
  { id: "menarakl", name: "Menara KL 5×5", w: 5, h: 5 },
  { id: "klcc", name: "Petronas 9×6", w: 9, h: 6 },
  { id: "gerbang", name: "Gateway Arch 2×1", w: 2, h: 1 },
  { id: "menaratelekom", name: "Telecom Tower 2×2", w: 2, h: 2 },
  { id: "menarautama", name: "Merdeka 118 7×6", w: 7, h: 6 },
];

const TIERS = ["Kampung", "Small Town", "City", "Big City", "Metropolis"];

let UNLOCK_NAMES = [
  "Aerospace Composites Plant",
  "Arterial Road",
  "Balai Raya",
  "Bangunan Warisan",
  "Bank Branch",
  "Battery Gigafactory",
  "Biotech Campus",
  "Car Assembly Plant",
  "Chip Assembly Plant",
  "Chip Gigafab",
  "Community Hall",
  "Container Port",
  "Convention Centre",
  "Crumb Rubber Factory",
  "Dam and Reservoir",
  "Data Centre",
  "Dataran Bandar",
  "Dataran Lang",
  "Depoh Bas",
  "Depoh Kejuruteraan",
  "Diesel Generator",
  "Dirt Road",
  "District Council Office",
  "District Police HQ",
  "Fire Station",
  "Fish Ponds",
  "Floating Wind Turbine",
  "Food Court",
  "Food Factory",
  "Football Field",
  "Fruit Packing Shed",
  "Gas Power Plant",
  "Gereja",
  "Glove Factory",
  "Gurdwara",
  "Health Clinic",
  "Hentian Bas",
  "Hospital Daerah",
  "Hospital Pakar",
  "Hypermarket",
  "Ice Factory",
  "Island Wind Jetty",
  "Jeti Nelayan",
  "Kampung Road",
  "Kedai Kopi",
  "Keropok Factory",
  "KLIA Main Terminal",
  "KLIA Runway",
  "KLIA Satellite Terminal",
  "Kolam Takungan",
  "Kompleks Sukan",
  "Krematorium",
  "Kuil",
  "Kuil Besar",
  "Lebuhraya",
  "Loji Rawatan Kumbahan",
  "LRT line",
  "Main Road",
  "Masjid",
  "Masjid Negeri",
  "Menara Jam",
  "Menara Kuala Lumpur",
  "Merdeka 118",
  "Mini Hydro",
  "Multipurpose Hall",
  "Offshore Wind Turbine",
  "Palm Oil Mill",
  "Palm Oil Refinery",
  "Pasar Basah",
  "Pasar Malam",
  "Petrol Station",
  "Petronas Twin Towers",
  "Playground",
  "Police Post",
  "Police Station",
  "Politeknik",
  "Post Office",
  "Prawn Ponds",
  "Public Library",
  "Public Park",
  "Restoran",
  "Rice Mill",
  "River Fish Cages",
  "River Pump",
  "Rubber Smokehouse",
  "Rural Clinic",
  "Saluran Keluar Kumbahan",
  "Sawmill",
  "Sea Fish Farm",
  "Sekolah Kebangsaan",
  "Shipyard",
  "Shopping Mall",
  "SJK (C)",
  "SJK (T)",
  "SME Factory Park",
  "SMK",
  "SOFO Suites",
  "Solar Cell Factory",
  "Solar Farm",
  "Soy Sauce Factory",
  "Stadium",
  "Steel Mill",
  "Stesen LRT",
  "Substation",
  "Supermarket",
  "Surau",
  "Tadika",
  "Tanah Perkuburan Bukan Islam",
  "Tanah Perkuburan Bukan Islam Besar",
  "Tanah Perkuburan Islam",
  "Tanah Perkuburan Islam Besar",
  "Telecom Tower",
  "Terminal Bas Ekspres",
  "TNB Grid Connection",
  "Tokong",
  "Tokong Besar",
  "Town Gateway Arch",
  "Town Hotel",
  "Tugu Wau",
  "Universiti",
  "Wafer Fab",
  "Water Tank",
  "Water Tower",
  "Water Treatment Plant",
  "Well",
  "Wind Turbine",
]

const LM_MAX = 100;


function addLandmarks(save, spec) {
  const L = LANDMARKS.find((l) => l.id === spec.id);
  if (!L || !save || !Array.isArray(save.bld) || !save.W) return 0;
  const W = save.W, H = save.H, bld = save.bld;
  const road = save.road || [], zone = save.zone || [], ter = save.terrain || [];
  const free = (x, y) => {
    if (x < 0 || y < 0 || x + L.w > W || y + L.h > H) return false;
    for (let j = y; j < y + L.h; j++)
      for (let i = x; i < x + L.w; i++) {
        const k = j * W + i;
        if (bld[k] !== -1 || road[k] || zone[k] || (ter.length && ter[k] !== 0)) return false;
      }
    return true;
  };
  save.buildings = save.buildings || {};
 
  const had = Object.values(save.buildings).filter((b) => b && b.kind === 5 && b.svc === L.id);
  had.sort((a, b) => a.id - b.id);
  
  for (const extra of had.slice(spec.n)) {
    for (let j = extra.y; j < extra.y + extra.h; j++)
      for (let i = extra.x; i < extra.x + extra.w; i++)
        if (bld[j * W + i] === extra.id) bld[j * W + i] = -1;
    delete save.buildings[extra.id];
  }

  let made = 0;
  const wanted = Math.max(0, spec.n - Math.min(had.length, spec.n));
  for (let n = 0; n < wanted; n++) {
    let at = null;
    for (let y = 0; y + L.h <= H && !at; y++)
      for (let x = 0; x + L.w <= W && !at; x++) if (free(x, y)) at = { x, y };
    if (!at) break;
    const id = save.nextId ?? (Object.keys(save.buildings).reduce((m, k) => Math.max(m, +k), 0) + 1);
    save.nextId = id + 1;
    save.buildings[id] = {
      id, kind: 5, x: at.x, y: at.y, w: L.w, h: L.h, crop: 0, level: 1, state: "active",
      days: 0, facing: 0, residents: 0, jobOf: [], staff: [], everOccupied: false, income: 0,
      revenue: 0, customers: 0, food: 0, sat: 50, emptyDays: 0, belowFloorDays: 0,
      variant: 1005, yard: [], svc: L.id, load: 0,
    };
    for (let j = at.y; j < at.y + L.h; j++)
      for (let i = at.x; i < at.x + L.w; i++) bld[j * W + i] = id;
    made++;
  }
  return made;
}



function polRecord(obj) {
  const day = Math.floor(Number(obj.tick || 0) / 24);
  return { on: day, n: 0, told: 0, reviews: [], kpi: { cur: [0, 0, 0, 0, 0, 0, 0, 0], m: [] }, term: day };
}

function transformSave(obj, st) {
  if (st.tier) obj.tier = st.tier;
  if (st.politik && obj.social && !obj.social.pol) obj.social.pol = polRecord(obj);
  // 0.3.0 disasters: floods, flash floods, tornadoes, road collapses, river level.

  if (st.bencana && obj.social) {
    obj.social.bencana = "on";
    delete obj.social.bencanaNext;

    obj.weather = { ...(obj.weather || {}), off: false };
  }
  if (st.unlock) obj.unlocked = [...new Set([...(obj.unlocked || []), ...UNLOCK_NAMES])].sort();
  if (st.pop) {
    obj.stats = { ...(obj.stats || {}), pop: POP };
  
    if (UNLOCK_NAMES.length)
      obj.unlocked = [...new Set([...(obj.unlocked || []), ...UNLOCK_NAMES])].sort();
  }
  if (st.money) obj.money = MONEY;
  if (st.lm) addLandmarks(obj, st.lm);
  return obj;
}


function cityId(save) {
  if (!save) return null;
  return { cid: save.cid ?? null, seed: save.seed ?? null, W: save.W ?? null, H: save.H ?? null };
}
function sameCity(a, b) {
  const x = cityId(a), y = cityId(b);
  if (!x || !y) return false;
  if (x.cid || y.cid) return x.cid === y.cid;
  return x.seed === y.seed && x.W === y.W && x.H === y.H;
}
function parseSave(raw) {
  try { return JSON.parse(raw); } catch { return null; }
}


function isPatched(obj, st) {
  if (!obj) return false;
  if (st.money && obj.money !== MONEY) return false;
  if (st.tier && obj.tier !== TIERS.indexOf(st.tier)) return false;
  if (st.bencana && !(obj.social && obj.social.bencana === "on" && !(obj.weather && obj.weather.off))) return false;
  if (st.politik && !(obj.social && obj.social.pol)) return false;
 
  if (st.pop && (!UNLOCK_NAMES.length || !UNLOCK_NAMES.every((n) => (obj.unlocked || []).includes(n)))) return false;
  if (st.unlock && !UNLOCK_NAMES.every((n) => (obj.unlocked || []).includes(n))) return false;
  if (st.lm) {
    const n = Object.values(obj.buildings || {}).filter((b) => b && b.kind === 5 && b.svc === st.lm.id).length;
    if (n < st.lm.n) return false;
  }
  return true;
}
