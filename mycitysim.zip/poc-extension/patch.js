
(() => {
  const MARK = "kaizen.pending";
  const PIN = "kaizen.pop";

  // expansion id -> the page flag the popup writes for it
  const XP_FLAGS = [
    { id: "politik",   flag: "kaizen.politik" },
    { id: "pelancong", flag: "kaizen.crime" },
  ];

  try {
    const raw = localStorage.getItem(MARK);
    if (raw) {
      const rec = JSON.parse(raw);
      if (rec && typeof rec.key === "string" && typeof rec.data === "string") {
        localStorage.setItem(rec.key, rec.data);
      }
      localStorage.removeItem(MARK);
    }
  } catch {}

  // ---- Expansions (0.3.0 Politikal Disaster, Tourism and Crime) ----
  // Every expansion is owned from two places, and its "Turn on" checks both
  // before it writes into the save:
  //
  //   fr(id)  -> id is in localStorage["mycitysim.owns"], read once while the
  //              bundle initialises (a comma list, snapshot taken at module load)
  //   $h(id)  -> id is in the account's my_expansions() list, fetched over
  //              fetch() and required on top of fr on the web (native Android
  //              always owns it)
  //
  // Both hooks are skipped entirely when a flag reads "0", so the popup can
  // put a single expansion's lock back. Absence of the flag means unlocked.

  const want = (x) => {
    try { return localStorage.getItem(x.flag) !== "0"; } catch { return true; }
  };
  const owned = XP_FLAGS.filter(want).map((x) => x.id);

  if (owned.length) {
    // any later read of the owns list still answers yes
    try {
      const get = Storage.prototype.getItem;
      Storage.prototype.getItem = function (k) {
        const v = get.call(this, k);
        if (k !== "mycitysim.owns") return v;
        const list = (v || "").split(",").filter(Boolean);
        const add = owned.filter((id) => !list.includes(id));
        return add.length ? list.concat(add).join(",") : v;
      };
    } catch {}
    try {
      const list = (localStorage.getItem("mycitysim.owns") || "").split(",").filter(Boolean);
      const add = owned.filter((id) => !list.includes(id));
      if (add.length) localStorage.setItem("mycitysim.owns", list.concat(add).join(","));
    } catch {}

    const nativeFetch = window.fetch;
    if (typeof nativeFetch === "function" && !nativeFetch.__kaizenXp) {
      const hooked = function (input) {
        const answer = nativeFetch.apply(this, arguments);
        try {
          const url = typeof input === "string" ? input : (input && input.url) || "";
          if (/\/rpc\/my_expansions(?:\?|$)/.test(url)) {
            return answer.then(async (res) => {
              if (!res || !res.ok) return res;
              const list = await res.clone().json().catch(() => null);
              if (!Array.isArray(list)) return res;
              const add = owned.filter((id) => !list.includes(id));
              if (!add.length) return res;
              return new Response(JSON.stringify(list.concat(add)), {
                status: res.status,
                statusText: res.statusText,
                headers: { "Content-Type": "application/json" },
              });
            });
          }
        } catch {}
        return answer;
      };
      hooked.__kaizenXp = true;
      window.fetch = hooked;
    }
  }


  let wantBn = false;
  try { wantBn = localStorage.getItem("kaizen.bencana") === "1"; } catch {}
  if (wantBn) {
    try { localStorage.setItem("mycitysim.weather", "on"); } catch {}
  }

  let pin = 0;
  try { pin = Number(localStorage.getItem(PIN)) || 0; } catch { return; }
  if (!(pin > 0)) return;

  const isSave = (o) =>
    !!o && typeof o === "object" &&
    Array.isArray(o.bld) &&
    !!o.buildings && typeof o.buildings === "object" &&
    !!o.stats && typeof o.stats === "object";

  const parse = JSON.parse;
  if (parse.__kaizenPin) return;
  const pinParse = function (text, reviver) {
    const v = parse.call(this, text, reviver);
    if (!isSave(v)) return v;
    let stats = v.stats;
    stats.pop = pin;
    Object.defineProperty(v, "stats", {
      configurable: true,
      enumerable: true,
      get() { return stats; },
      set(next) { if (next && typeof next === "object") stats = { ...next, pop: pin }; },
    });
    return v;
  };
  pinParse.__kaizenPin = pin;
  JSON.parse = pinParse;
})();
