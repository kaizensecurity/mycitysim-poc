"use strict";

const BASE = "https://bwhljuxdlhhuhyvagkod.supabase.co";
const KEY = "sb_publishable_GAtNgCuZdIlgbtDhUGcxvg_L5R-OMHa";

let SLOT = 1;
const FORGE = { pop: 9999999, day: 500000, sat: 100, tier: 5, tier_at: [0, 30, 60, 90, 120, 150] };

const $ = (id) => document.getElementById(id);
const master = $("master"), rankSw = $("rank"), moneySw = $("money"), unlockSw = $("unlock"),
      tierSel = $("tier"), popSw = $("pop"), lmSel = $("lm"), lmN = $("lmN"),
      politikSw = $("politik"), crimeSw = $("crime"), bencanaSw = $("bencana");
const statusEl = $("status"), masterState = $("masterState");

function log(msg, cls) {
  statusEl.innerHTML = cls ? `<span class="${cls}">${msg}</span>` : msg;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) throw new Error("no active tab");
  if (!/^https:\/\/mycitysim\.app\//.test(tab.url || "")) throw new Error("open https://mycitysim.app/ first");
  return tab;
}

async function getToken(tab) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => {
      const k = Object.keys(localStorage).find((x) => x.includes("-auth-token"));
      if (!k) return null;
      try {
        const raw = JSON.parse(localStorage.getItem(k));
        return (raw && (raw.access_token || (raw.currentSession && raw.currentSession.access_token))) || null;
      } catch { return null; }
    },
  });
  const tok = res && res.result;
  if (!tok) throw new Error("not signed in on this tab");
  return tok;
}

function jwtPayload(tok) {
  try {
    const part = String(tok).split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(part));
  } catch { return null; }
}

async function detectSession() {
  const el = $("session");
  try {
    const tab = await activeTab();
    const tok = await getToken(tab);
    const p = jwtPayload(tok) || {};
    const exp = p.exp ? new Date(p.exp * 1000).toISOString().slice(0, 10) : "no exp";
    const uid = p.sub ? p.sub.slice(0, 8) + "…" : "linked";
    el.textContent = `session : ${uid} · expires ${exp}`;
    el.className = "sub ok";
  } catch (e) {
    el.textContent = "no session found — open https://mycitysim.app/ signed in";
    el.className = "sub warn";
  }
}

async function sb(path, { method = "GET", body, token } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      apikey: KEY,
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const code = data && data.code ? `${res.status} ${data.code}` : String(res.status);
    throw new Error(code + " " + (data && data.message ? data.message : ""));
  }
  return data;
}

// --- gzip/base64---
function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function bytesToB64(bytes) {
  let s = "";
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}
async function gunzip(b64) {
  const stream = new Blob([b64ToBytes(b64)]).stream().pipeThrough(new DecompressionStream("gzip"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function gzip(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("gzip"));
  return bytesToB64(new Uint8Array(await new Response(stream).arrayBuffer()));
}

// money may be stored as a float (e.g. 65016.2), so consume the decimal part too
const MONEY_RE = /("money"\s*:\s*)(-?\d+(?:\.\d+)?)/;

async function readBlob(b64) {
  const text = new TextDecoder().decode(await gunzip(b64));
  const m = MONEY_RE.exec(text);
  let tick = null, name = null, cid = null, tier = null;
  try { const o = JSON.parse(text); tick = o.tick; name = o.name; cid = o.cid; tier = o.tier; } catch {}
  return { money: m ? Number(m[2]) : null, tick, name, cid, tier };
}

async function withMoney(b64, amount) {
  const bytes = await gunzip(b64);
  const text = new TextDecoder().decode(bytes);
  if (!MONEY_RE.test(text)) throw new Error('no "money" field in blob');
  const patched = text.replace(MONEY_RE, (_m, p1) => p1 + String(amount));
  return gzip(new TextEncoder().encode(patched));
}

async function transform(b64, st) {
  // the fast path skips re-serialising the blob, so anything transformSave has
  // to write (including the expansion flags) has to be listed here or the cloud
  // copy would silently keep the un-patched state
  if (!st.tier && !st.politik && !st.crime && !st.bencana && !st.unlock && !st.pop && !st.lm) {
    return st.money ? await withMoney(b64, MONEY) : b64;
  }
  const obj = transformSave(JSON.parse(new TextDecoder().decode(await gunzip(b64))), st);
  return gzip(new TextEncoder().encode(JSON.stringify(obj)));
}

// --- to add lzip ---



async function readLocal(tab) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => {
      const s = Number(localStorage.getItem("mycitysim.slot") || 1);
      const key = s === 1 ? "mycitysim.save.v1" : "mycitysim.save.v1." + s;
      const raw = localStorage.getItem(key);
      if (!raw) return { ok: false, key };
      let tier = null;
      try { tier = JSON.parse(raw).tier ?? null; } catch {}
      return { ok: true, key, raw, tier };
    },
  });
  return res.result;
}


const PENDING = "kaizen.pending";

async function writeLocal(tab, key, raw) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [key, raw, PENDING],
    func: (key, raw, mark) => {
      if (!key || typeof raw !== "string") return { ok: false, reason: "bad args" };
      localStorage.setItem(key, raw);
      localStorage.setItem(mark, JSON.stringify({ key, data: raw, at: Date.now() }));
      return { ok: true };
    },
  });
  return res.result;
}


async function setPopPin(tab, on) {
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [POP_PIN_KEY, on ? String(POP) : ""],
    func: (key, value) => {
      try { value ? localStorage.setItem(key, value) : localStorage.removeItem(key); } catch {}
    },
  });
}


// patch.js reads this flag at document_start and turns it into both ownership
// checks the 0.3.0 bundle makes: localStorage["mycitysim.owns"] and the
// my_expansions() RPC. It has to be in the page, not in chrome.storage.
async function setPolitik(tab, on) {
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [on ? "1" : "0"],
    func: (v) => {
      // "0" disables; absence means on (patch.js defaults to unlocked)
      try { localStorage.setItem("kaizen.politik", v); } catch {}
    },
  });
}

// same deal as setPolitik: patch.js reads kaizen.crime at document_start and
// turns it into both ownership checks for the pelancong ("Tourism and Crime")
// expansion — the mycitysim.owns snapshot and the my_expansions() RPC.
async function setCrime(tab, on) {
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [on ? "1" : "0"],
    func: (v) => {
      // "0" disables; absence means on (patch.js defaults to unlocked)
      try { localStorage.setItem("kaizen.crime", v); } catch {}
    },
  });
}

// patch.js reads this at document_start. Disasters need the device's weather on
// (weather off => no floods, and the City info card says exactly that), so with
// the switch on the flag makes patch.js put "mycitysim.weather" back to "on".
async function setBencanaFlag(tab, on) {
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [on ? "1" : "0"],
    func: (v) => {
      try {
        if (v === "1") localStorage.setItem("kaizen.bencana", "1");
        else localStorage.removeItem("kaizen.bencana");
      } catch {}
    },
  });
}

async function resetBudget(tab) {
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => { try { sessionStorage.removeItem("kaizen.autoloads"); } catch {} },
  });
}

async function patchLocal(tab, st) {
  const cur = await readLocal(tab);
  if (!cur.ok) return { ok: false, key: cur.key, reason: "no city saved in this tab yet" };
  const before = JSON.parse(cur.raw);

  const base = (st.localSnap && st.localSnap.raw) || cur.raw;
  const save = transformSave(JSON.parse(base), st);
  const w = await writeLocal(tab, cur.key, JSON.stringify(save));
  if (!w.ok) return { ok: false, key: cur.key, reason: w.reason || "write failed" };

  const copies = st.lm
    ? Object.values(save.buildings || {}).filter((b) => b && b.kind === 5 && b.svc === st.lm.id).length
    : null;
  return { ok: true, key: cur.key, wasTier: before.tier ?? null, tier: save.tier ?? null,
           pop: save.stats && save.stats.pop, copies, wanted: st.lm && st.lm.n,
           buildings: Object.keys(save.buildings || {}).length,
           added: (save.buildings ? Object.keys(save.buildings).length
                                  : 0) - Object.keys(before.buildings || {}).length };
}

async function restoreLocal(tab, snap) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [snap.key, snap.raw, PENDING],
    func: (key, raw, mark) => {
      if (!key || typeof raw !== "string") return { ok: false, reason: "bad snapshot" };
      localStorage.setItem(key, raw);
      localStorage.setItem(mark, JSON.stringify({ key, data: raw, at: Date.now() }));
      let tier = null;
      try { tier = JSON.parse(raw).tier ?? null; } catch {}
      return { ok: true, key, tier };
    },
  });
  return res.result;
}

// --- state ---
async function getState() {
  const st = await chrome.storage.local.get(["master", "rank", "money", "unlock", "tier", "pop",
                                            "lm", "lmN", "snap", "localSnap", "politik", "crime", "bencana"]);
  const n = Math.min(LM_MAX, Math.max(1, Number(st.lmN) || 1));
  return { master: !!st.master, rank: st.rank !== false, money: st.money !== false,
           unlock: st.unlock !== false, tier: TIERS.includes(st.tier) ? st.tier : null,
           pop: !!st.pop, politik: st.politik !== false, crime: st.crime !== false,
           bencana: !!st.bencana,
           lm: LANDMARKS.some((l) => l.id === st.lm) ? st.lm : null,
           lmN: n, snap: st.snap || null, localSnap: st.localSnap || null };
}
async function setState(patch) {
  await chrome.storage.local.set(patch);
}


async function gameTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab && /^https:\/\/mycitysim\.app\//.test(tab.url || "") ? tab : null;
}
async function mirrorState(st) {
  const tab = await gameTab();
  if (!tab) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [MIRROR_KEY, JSON.stringify({ at: Date.now(), state: st })],
    func: (key, value) => { try { localStorage.setItem(key, value); } catch {} },
  });
}
async function hydrateFromPage() {
  const cur = await chrome.storage.local.get("master");
  if (cur.master !== undefined) return false;
  const tab = await gameTab();
  if (!tab) return false;
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    args: [MIRROR_KEY],
    func: (key) => { try { return localStorage.getItem(key); } catch { return null; } },
  });
  let m = null;
  try { m = JSON.parse(res && res.result); } catch {}
  if (!m || !m.state) return false;
  await chrome.storage.local.set(m.state);
  log("storage was empty — switches and snapshots restored from the page mirror", "ok");
  return true;
}

async function currentRow(tab) {
  const token = await getToken(tab);
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => Number(localStorage.getItem("mycitysim.slot") || 1),
  });
  const want = Number(res && res.result) || 1;
  const rows = await sb(`/rest/v1/saves?select=*&order=rev.desc`, { token });
  if (!rows || !rows.length) return { row: null, token, want, slots: 0 };
  const hit = rows.find((r) => r.slot === want) || rows[0];
  SLOT = hit.slot;
  return { row: hit, token, want, slots: rows.length };
}

function metricsOf(row) {
  return { pop: row.pop, day: row.game_day, sat: row.sat, tier: row.tier, tier_at: row.tier_at,
           city: row.city_name, map: row.map };
}

async function putSave(token, row, data, m) {
  const body = {
    p_slot: row.slot,
    p_data: data,
    p_game_version: "0.3.0",
    p_city_name: m.city,
    p_pop: m.pop,
    p_game_day: m.day,
    p_expected_rev: row.rev,
    p_tier: m.tier,
    p_map: m.map,
    p_sat: m.sat,
    p_tier_at: m.tier_at,
  };
  // 0.3.0's put_save takes the save's format (reader) and ruleset (rules). Without
  // them the server answers {ok:false, newer:true, behind:true} and drops the write.
  const extended = row.reader != null;
  if (extended) { body.p_reader = row.reader; body.p_rules = row.rules ?? null; }
  try {
    return await sb("/rest/v1/rpc/put_save", { method: "POST", token, body });
  } catch (e) {
    // older backends reject the unknown arguments outright - retry without them
    if (!extended || !/PGRST202|function/i.test(String(e.message || e))) throw e;
    delete body.p_reader; delete body.p_rules;
    return sb("/rest/v1/rpc/put_save", { method: "POST", token, body });
  }
}

async function applyPoC() {
  const st = await getState();
  if (!st.master) return revertPoC();

  const tab = await activeTab();
  const { row, token, want, slots } = await currentRow(tab);
  const uid = (jwtPayload(token) || {}).sub || null;
  // notes survive the final status line (a plain log() here is replaced by it a moment later)
  const notes = [];

  // the snapshot must belong to THIS account and slot: a leftover one from a previous account
  // would push that city's blob into the current slot on the next write
  let snap = st.snap;
  if (snap && (snap.uid !== uid || (row && snap.slot !== row.slot))) {
    notes.push(`stale cloud snapshot (other account or slot ${snap.slot}) discarded`);
    snap = null;
    await setState({ snap: null, localSnap: null });
  }
  if (!snap && row) {
    snap = {
      takenAt: Date.now(),
      uid,
      slot: SLOT,
      data: row.data,
      metrics: metricsOf(row),
      city: row.city_name,
      rev: row.rev,
    };
    await setState({ snap });
    notes.push("pristine cloud snapshot captured");
  }
  if (!row) {
    notes.push(`no cloud row yet (tab slot ${want}, ${slots} row(s)) — patching the local save; ` +
               `the next in-game save uploads it`);
  }

  
  const cur = await readLocal(tab);
  const live = cur.ok ? parseSave(cur.raw) : null;
  let localSnap = st.localSnap;
  if (localSnap) {
   
    const owner = localSnap.uid || null;         
    const otherAccount = owner && owner !== uid;
    const otherCity = live && !sameCity(parseSave(localSnap.raw), live);
    if (otherAccount || otherCity) {
      notes.push(otherAccount ? "snapshot from a previous account discarded"
                              : "snapshot was for a different city discarded");
      localSnap = null;
      await setState({ localSnap: null });
    }
  }
  if (!localSnap && cur.ok) {
    localSnap = { uid, key: cur.key, raw: cur.raw, tier: cur.tier, ...cityId(live) };
    await setState({ localSnap });
  }
  if (!cur.ok) {
    notes.push(`no city saved in this tab yet (${cur.key}) — press Play, then toggle again`);
  }

 
  const spec = { ...st, localSnap, lm: st.lm ? { id: st.lm, n: st.lmN } : null };

  const local = await patchLocal(tab, spec);
  await setPopPin(tab, st.pop);
  await resetBudget(tab);

  let out = null, cloudErr = null;
  if (row && snap) {
    for (let attempt = 0; attempt < 2 && !out; attempt++) {
      try {
        const fresh = attempt === 0 ? row : (await currentRow(tab)).row;
        if (!fresh) break;
        const data = await transform(snap.data, spec);
        const m = st.rank
          ? { pop: FORGE.pop, day: FORGE.day, sat: FORGE.sat, tier: FORGE.tier, tier_at: FORGE.tier_at,
              city: snap.city, map: fresh.map }
          : { ...snap.metrics, city: snap.city, map: fresh.map };
        if (st.tier) {
          m.tier = TIERS.indexOf(st.tier);
          // the cloud row otherwise keeps its Metropolis-length timeline
          m.tier_at = tierTimeline(m.tier_at, m.tier);
        }
      
        out = await putSave(token, fresh, data, m);
      } catch (e) { cloudErr = String(e.message || e); }
    }
  }
  log(`applied · ${out ? `rev ${out.rev}`
         : cloudErr ? `cloud FAILED (${cloudErr}) — local save still patched`
         : "cloud skipped (no row yet)"} · ` +
      `rank ${st.rank ? "on" : "off"} · ` +
      `money ${st.money ? "on" : "off"} · unlocks ${st.unlock ? "on" : "off"} · ` +
      `tier ${st.tier || "off"} · pop ${st.pop ? POP : "off"} · ` +
      `landmark ${st.lm ? `${st.lm}×${st.lmN}` : "off"}\n` +
      (notes.length ? notes.join(" · ") + "\n" : "") +
      (local.ok ? `local save: tier ${local.wasTier} -> ${local.tier} · pop ${local.pop} · ` +
                  `buildings ${local.buildings} (+${local.added})` +
                  (local.copies != null
                    ? ` · copies ${local.copies}/${local.wanted}` +
                      (local.copies < local.wanted ? " (no free tiles left)" : "")
                    : "")
                : `local save NOT patched: ${local.reason}`));

  const applied = statusEl.innerHTML;
  await refreshStatus();
  statusEl.innerHTML = applied + "\n" + statusEl.innerHTML;
 
  if (local.ok) {
    const keep = statusEl.innerHTML;
    await chrome.tabs.reload(tab.id);
    statusEl.innerHTML = keep + "\n" + '<span class="ok">tab reloaded — the game boots from the patched save</span>';
  }
}

async function revertPoC() {
  const st = await getState();
  if (!st.snap && !st.localSnap) { log("nothing to revert — no snapshot stored", "warn"); return; }
  const tab = await activeTab();
  await setPopPin(tab, false);
  const { row, token } = await currentRow(tab);
  
  let localNote = "local save untouched";
  if (st.localSnap) {
    const back = await restoreLocal(tab, st.localSnap);
    localNote = back.ok ? `local save restored (tier ${back.tier}) — reloaded` : "local restore failed";
    await setState({ localSnap: null });
    if (back.ok) await chrome.tabs.reload(tab.id);
  }
  let out = null, cloudErr = null;
  
  const uid = (jwtPayload(token) || {}).sub || null;
  const sameOwner = !st.snap || !st.snap.uid || st.snap.uid === uid;
  const localOwner = !st.localSnap || !st.localSnap.uid || st.localSnap.uid === uid;
  if (st.localSnap && !localOwner) {
    await setState({ localSnap: null });
    localNote = "local save untouched (snapshot belonged to another account)";
  }
  if (st.snap && row && sameOwner && st.snap.slot === row.slot) {
    try {
      out = await putSave(token, row, st.snap.data, { ...st.snap.metrics, map: row.map });
    } catch (e) { cloudErr = String(e.message || e); }
  }
  await setState({ snap: null });
  log(`reverted · ${out ? `rev ${out.rev}`
         : cloudErr ? `cloud FAILED (${cloudErr}) — local save still restored`
         : "cloud unchanged"} · snapshot cleared\n${localNote}`, "ok");
  const revertedLine = statusEl.innerHTML;
  await refreshStatus();
  statusEl.innerHTML = revertedLine + "\n" + statusEl.innerHTML;
}


async function localSummary(tab) {
  try {
    const cur = await readLocal(tab);
    if (!cur.ok) return "local: no save";
    const s = JSON.parse(cur.raw);
    const marks = Object.values(s.buildings || {})
      .filter((b) => b && b.kind === 5 && LANDMARKS.some((l) => l.id === b.svc))
      .map((b) => b.svc);
    return `local: tier ${s.tier || "(none)"} · pop ${s.stats && s.stats.pop} · ` +
           `money ${s.money} · landmarks ${marks.length ? marks.join(",") : "none"}`;
  } catch { return "local: unreadable"; }
}

async function refreshStatus() {
  try {
    const tab = await activeTab();
    const { row, token, want, slots } = await currentRow(tab);
    if (!row) {
      log(`cloud: no save row yet — the game has not uploaded once (tab slot ${want}, ` +
          `rows on account: ${slots})\n` + (await localSummary(tab)), "warn");
      return;
    }
    const b = await readBlob(row.data);
    let rankTxt = "hidden";
    try {
      const lb = await sb("/rest/v1/rpc/leaderboard", { method: "POST", token,
        body: { p_board: "pop", p_map: null } });
      const me = lb && lb.me;
      rankTxt = me && me.rank ? `#${me.rank} (${me.value})` : "not ranked";
    } catch (e) { rankTxt = "?"; }
    log(`slot ${row.slot} · rev ${row.rev} · pop ${row.pop} · day ${row.game_day} · money ${b.money}\n` +
        `tier ${b.tier || "(none)"} blob / ${row.tier} column · pop board: ${rankTxt}\n` +
        `city ${row.city_name}\n` + (await localSummary(tab)));
  } catch (e) {
    log(String(e.message || e), "bad");
  }
}

function syncUi(st) {
  master.checked = st.master;
  rankSw.checked = st.rank;
  moneySw.checked = st.money;
  unlockSw.checked = st.unlock;
  tierSel.value = st.tier || "";
  popSw.checked = st.pop;
  lmSel.value = st.lm || "";
  lmN.value = String(st.lmN);
  politikSw.checked = st.politik;
  crimeSw.checked = st.crime;
  bencanaSw.checked = st.bencana;
  bencanaSw.disabled = !st.master;
  $("rowBencana").classList.toggle("disabled", !st.master);
  rankSw.disabled = !st.master;
  moneySw.disabled = !st.master;
  unlockSw.disabled = !st.master;
  tierSel.disabled = !st.master;
  popSw.disabled = !st.master;
  lmSel.disabled = !st.master;
  lmN.disabled = !st.master || !st.lm;
  $("rowRank").classList.toggle("disabled", !st.master);
  $("rowMoney").classList.toggle("disabled", !st.master);
  $("rowUnlock").classList.toggle("disabled", !st.master);
  $("rowTier").classList.toggle("disabled", !st.master);
  $("rowPop").classList.toggle("disabled", !st.master);
  $("rowLm").classList.toggle("disabled", !st.master);
  // the snapshot is what makes the revert possible, so say so instead of just "held"
  masterState.textContent = st.master
    ? (st.snap || st.localSnap ? "on — snapshot held, so revert can undo the change"
                              : "on — writing, no snapshot yet (revert unavailable)")
    : "off — snapshot restored";
}

async function guard(fn) {
  try { await fn(); } catch (e) { log(String(e.message || e), "bad"); }
  const st = await getState();
  syncUi(st);
  try { await mirrorState(st); } catch {}
}

// --- wiring ---
master.addEventListener("change", () => guard(async () => {
  await setState({ master: master.checked });
  await applyPoC();
}));
rankSw.addEventListener("change", () => guard(async () => {
  await setState({ rank: rankSw.checked });
  await applyPoC();
}));
moneySw.addEventListener("change", () => guard(async () => {
  await setState({ money: moneySw.checked });
  await applyPoC();
}));
unlockSw.addEventListener("change", () => guard(async () => {
  await setState({ unlock: unlockSw.checked });
  await applyPoC();
}));
tierSel.addEventListener("change", () => guard(async () => {
  await setState({ tier: tierSel.value || null });
  await applyPoC();
}));
popSw.addEventListener("change", () => guard(async () => {
  await setState({ pop: popSw.checked });
  await applyPoC();
}));
lmSel.addEventListener("change", () => guard(async () => {
  await setState({ lm: lmSel.value || null });
  await applyPoC();
}));
lmN.addEventListener("change", () => guard(async () => {
  const n = Math.min(LM_MAX, Math.max(1, Number(lmN.value) || 1));
  await setState({ lmN: n });
  await applyPoC();
}));
bencanaSw.addEventListener("change", () => guard(async () => {
  await setState({ bencana: bencanaSw.checked });
  const tab = await gameTab();
  if (tab) await setBencanaFlag(tab, bencanaSw.checked && (await getState()).master);
  await applyPoC();
}));
politikSw.addEventListener("change", () => guard(async () => {
  const on = politikSw.checked;
  await setState({ politik: on });
  const tab = await activeTab();
  await setPolitik(tab, on);
  await chrome.tabs.reload(tab.id);
  log(on ? "Politikal Disaster unlocked \u2014 reloaded; open City info \u203a Majlis and Turn on Politics"
         : "Politikal Disaster lock restored \u2014 reloaded", "ok");
}));
crimeSw.addEventListener("change", () => guard(async () => {
  const on = crimeSw.checked;
  await setState({ crime: on });
  const tab = await activeTab();
  await setCrime(tab, on);
  await chrome.tabs.reload(tab.id);
  log(on ? "Tourism \u0026 Crime unlocked \u2014 reloaded; open City info \u203a Majlis and Turn on"
         : "Tourism \u0026 Crime lock restored \u2014 reloaded", "ok");
}));
$("refresh").addEventListener("click", () => guard(async () => {
  await refreshStatus();
}));
$("reload").addEventListener("click", () => guard(async () => {
  const tab = await activeTab();
  await chrome.tabs.reload(tab.id);
  log("game tab reloaded — the patched local save is now what the UI reads", "ok");
}));

// sanity check on open
(async () => {
  try { await hydrateFromPage(); } catch {}
  // the page flags live in localStorage and can be cleared with site data, so
  // re-assert them from chrome.storage whenever the popup opens — in both
  // directions, or an "off" switch would silently read as unlocked again
  try {
    const st = await getState();
    const tab = await gameTab();
    if (tab) {
      await setPolitik(tab, st.politik);
      await setCrime(tab, st.crime);
      await setBencanaFlag(tab, !!st.master && st.bencana);
    }
  } catch {}
  await detectSession();
  guard(async () => { await refreshStatus(); });
})();
